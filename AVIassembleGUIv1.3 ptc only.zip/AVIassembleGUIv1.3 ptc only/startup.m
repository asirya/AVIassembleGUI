% Startup file
if ispc

elseif ismac
    cd '~/Downloads';
    diary on;
    disp('Current directory is:')
    disp (pwd)
    disp('Exciting analysis session: enabled.')
end
AVIassembleGUI_App