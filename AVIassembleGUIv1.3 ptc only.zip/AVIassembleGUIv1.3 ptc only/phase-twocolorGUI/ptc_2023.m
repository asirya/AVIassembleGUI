function ptcoutput = ptc(settings1)
%based on phase-twocolor1_72.m
%   Does most of the work for ptcGUI.m
%v.1.1 cleaned up settings
%v.pctGUI1.0.120402 
%pctGUI1.0.120711 - adds counting # of cells above an arbitrary threshold
                %reordered imdilate->holes->imopen->imclose 
                %                       to 
                %          holes->imopen->(imclose)->imdilate
                %for both phasefill, phasefill2
%ptcGUI120717-uses autocontrast.m
%ptcGUI2017-04-19 adds settings.filloutborder to fill out the border without removing cell masks along the border
%ptcGUI2017-04-24 reports avgbackground1,2
%2017-09-21 updated to report cell area, fixed display cell size histogram broken for 2 fluorsuffixes
%2017-09-23 updated to work with PC / mac
%2018-01-17 updated for timelapse fluor/area, are headings
%2018-04-25 changes by Henry. See changelog for details
%2018-05-03 changes by Henry. See changelog for details
%-updated instances of "imfilter" to "imgaussfilt"
%-updated "wavread" to "audioread"
%2018-05-17 changes by Henry: 
%programmode 2: localization, stores phase image for each individual cell, x, y coordinates for each cell. Outputs
%Gaussian fit, peaktobackground, and images to seperate outputWindow
%2018-10-30 AS changes: doesn't work with single fluorescence channels right now. added programmode changes to surround henry changes

clear settings;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Begin new settings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
settings=settings1;
display(settings);
%####################
%Start to fun times #
%####################
currentdir=uigetdir(pwd);

if not(currentdir)
    disp('Error: directory not selected.');
    return;
end

%cd(currentdir);

dirname=regexprep(currentdir,'-','_');
dirname=regexprep(dirname,'\+','plus');
dirname=regexprep(dirname,' ','_');
dirname=regexprep(dirname,'\.','dot');
if ismac
    positions=regexp(dirname,'/');
else
    positions=regexp(dirname,'\');
end
%positions(length(positions));
dirname=dirname((positions(length(positions))+1):length(dirname));


%Find folders/files in current directory
for j=settings.foldersuffixstart:1:settings.foldersuffixend
    results=[];
    
    %Henry's Values
    localResults = [];
    myFileNames = {};
    pictureArray = {};
    %End of Henry Results
    
    intensityarray=[];
    individualratioarray=[];
    avgbackgroundarray1=[];
    avgbackgroundarray2=[];
    fluorfiles1={};
    fluorfiles2={};
    phasefiles={};
    phasefiles2={};
    if strcmp(settings.foldersuffixtype,'number')
        suffix=int2str(j);
    elseif strcmp(settings.foldersuffixtype,'letter')
        suffix=settings.foldersuffixtranslator{2,j};
    elseif strcmp(settings.foldersuffixtype,'LETTER')
        suffix=settings.foldersuffixtranslator{3,j};
    elseif strcmp(settings.foldersuffixtype,'none')
        suffix='';
    end
    %workingdir=strcat(pwd,'/', settings.foldername,settings.connector,suffix);
    if ~isempty(settings.foldername)
        workingdir=strcat(currentdir,'/', settings.foldername,settings.connector,suffix);
    else
        workingdir=currentdir;
    end
    
    if settings.splitTIFFs
        if not(splitTIFFs1_1(workingdir));
            Error('SplitTIFFs returned an error');
            return;
        end
    end
    fileinfo=dir(strcat(workingdir,'/*',settings.masksuffix, '.tif'));
    phasefiles=transpose({fileinfo.name});
    numberoffiles=length(phasefiles);
    
    %if no files are found, exit
    if numberoffiles==0
        error('No files found matching the suffixes');
        fileinfo=dir(strcat(workingdir,'/*.tif'));
        phasefiles=transpose({fileinfo.name});
        numberoffiles=length(phasefiles);
        if numberoffiles==0
            error('No tif files found. Exiting...');
            return;
        else
            %error(strcat('Found ', num2str(numberoffiles), 'files. Exiting...'));
            %splitTIFFs(workingdir);
        end
    end
    
    for k=phasefiles %Convert phase prefixes into fluorescent prefixes
        %fluorfiles1=cat(1,fluorfiles1,regexprep(k, settings.masksuffix, settings.fluorsuffix1));
        fluorfiles1=cat(1,fluorfiles1,regexprep(k, [settings.masksuffix '.tif'], [settings.fluorsuffix1 '.tif']));
        if not(isempty(settings.fluorsuffix2))
            %fluorfiles2=cat(1,fluorfiles2,regexprep(k, settings.masksuffix, settings.fluorsuffix2));
            fluorfiles2=cat(1,fluorfiles2,regexprep(k, [settings.masksuffix '.tif'], [settings.fluorsuffix2 '.tif']));
        end
    end
    
  
    for i=1:1:numberoffiles
        phasefill=[];
        phasefilllabel=[];
        %waitbar((i-1)/numberoffiles,progressbar);
        
        %open phase and fluorescent images. detect edges of phase image
        %1st image for mask
        settings.currentmask=1;
        if settings.usemask   %0 to use phase mask, 1 to use fluorsuffix2
            phase=imread(strcat(workingdir,'/',fluorfiles1{i,1}));
            %phase=imread(strcat(workingdir,'/timelapse6wellxy03t33-gfp_mask.tif'));
            %phase=gpuArray(phase);
            settings.sobel.threshold=0;
        else
            phase=imread(strcat(workingdir,'/',phasefiles{i,1}));  %use for phase mask
            %phase=imread(strcat(workingdir,'/timelapse6wellxy03t33-gfp_mask.tif'));
            %phase=gpuArray(phase);
        end
        
        if settings.invert
            phase=imcomplement(phase);
        end
        fp1=uint16(imread(strcat(workingdir,'/',fluorfiles1{i,1})));
        %fp1=gpuArray(fp1);
        
        if not(isempty(settings.fluorsuffix2))  %load fluorfiles2 if prefix is given
            fp2=imread(strcat(workingdir,'/',fluorfiles2{i,1}));
            %fp2=gpuArray(fp2);
        end

        se90 = strel('line', 5, 90); %image dilation kernel (structural element) dilate image using this kernel
        se0 = strel('line', 5, 0);
        
        myPhase = phase;
        
        if settings.autocontrast.on
            %display('running autocontrast...');
            
            %CHANGED BY HENRY
            %ORGINAL LINE:
            %phase=imfilter(phase, fspecial('gaussian',settings.autocontrast.blurrradius));
            phase=imgaussfilt(phase, settings.autocontrast.blurrradius);
            %END OF CHANGES
            phase=autocontrast(phase,settings.autocontrast.sigma); 
        end
           
        phaseorig=uint16(phase);
        
        if settings.thresholdmode == 1
            if i==1 && j==1
                s1value=settings.thresholdinterval.default;
                settings.edgemethod='threshold particle variation';
                %settings.thresholdvalue.dilate=1;
                s1value=edge_sobel_canny(phase,[settings.particlevariation.default settings.thresholdinterval.default], [1 1], [1000 1000], settings,phasefiles,workingdir);
                waitfor(s1value);
                settings.particlevariation.default=round(s1value(1));
                settings.thresholdinterval.default=round(s1value(2));
                m=0;
            end
            threshold=find_thresholdv1_2(phase, round(settings.particlevariation.default), round(settings.thresholdinterval.default),1,0);
            phasefill=(phase > threshold);
        end
        
        if settings.thresholdmode == 2
            m=1;
            if i==1 && j==1
                settings.edgemethod='canny';
                s1value=edge_sobel_canny(phase,[settings.canny.low settings.canny.high], [settings.canny.low*0.1 settings.canny.high*0.1], [settings.canny.low*2 settings.canny.high*2], settings,phasefiles,workingdir);
                waitfor(s1value);
                settings.canny.low=s1value(1);
                settings.canny.high=s1value(2);
                m=0;
            end
            %phasefill=imopen(imfill(imdilate(edge(phase, 'canny', [settings.canny.low settings.canny.high]), settings.structure), 'holes'),settings.structure2); %detect edge, dilate mask, fill mask holes, remove border particles
            %phasefill=edge(phase, 'canny', [settings.canny.low settings.canny.high]); %detect edge, dilate mask, fill mask holes, remove border particles
            phasefill=edge(phase, settings.edgemethod, s1value); %detect edge, dilate mask, fill mask holes, remove border particles
            %display(s1value);
            %phasefill=phase;
        end
        
        if settings.thresholdmode==3
            m=1;
            if i==1 && j==1
                settings.edgemethod='sobel';
                s1value=edge_sobel_canny(phase,settings.sobel.threshold,settings.sobel.threshold*0.1,settings.sobel.threshold*10,settings,phasefiles,workingdir);
                waitfor(s1value);
                settings.sobel.threshold=s1value;
                m=0;
            end
            %phasefill=imopen(imfill(imdilate(edge(phase, 'sobel', settings.sobel.threshold), settings.structure), 'holes'),settings.structure2); %detect edge, dilate mask, fill mask holes, remove border particles
            phasefill=edge(phase, 'sobel', settings.sobel.threshold);
        end
        
        if settings.thresholdmode==4
            if isfield(settings,'thresholdpixelvalue')
                s1value=settings.thresholdpixelvalue;
            else
                s1value=round(mean(mean(phase)));
            end
            
            if i==1 && j==1
                %display(settings.structure2);
                settings.edgemethod='threshold value';
                s1value=edge_sobel_canny(phase,s1value,min(min(phase)),max(max(phase)),settings,phasefiles,workingdir);
                waitfor(s1value);
                settings.thresholdpixelvalue=round(s1value);
                m=0;
            end

            phasefill=phase > settings.thresholdpixelvalue;
        end
        
        if settings.thresholdmode==5
            
        end
        
        if settings.imdilate
            phasefill=imdilate(phasefill, settings.structure);
        end      

        if settings.thresholdmode ~= 4
            phasefill=imfill(phasefill,'holes');
        end
        
        if settings.imopen
            phasefill=imopen(phasefill, settings.structure2);
        end
        
        if settings.imclose
            phasefill=imclose(phasefill,settings.structure2);
        end
        
        %phasefill=imclearborder(phasefill); %use temporarily to clear objects on the border on 2017-04-19. remove when not needed.
        %fill out border
        settings.filloutborder=1;
        if settings.filloutborder==1
            settings.bordersize=3;
            phasefill(1:settings.bordersize,:)=0;
            framemax=size(phasefill,1);
            framemin=framemax-settings.bordersize;
            phasefill(framemin:framemax,:)=0;
            phasefill(:,1:settings.bordersize)=0;
            framemax=size(phasefill,2);
            framemin=framemax-settings.bordersize;
            phasefill(:,framemin:framemax)=0;
        end
        
        %2nd image for mask
        %autocontrast off for 2nd mask for all types of edge previews
        %using settings.mask2 argument to edge_sobel_canny
        if not(isempty(settings.masksuffix2))
            settings.currentmask=2;
            for k=phasefiles
                phasefiles2=cat(1,phasefiles2,regexprep(k, settings.masksuffix, settings.masksuffix2));
            end
            
            phase2=imread(strcat(workingdir,'/',phasefiles2{i,1}));  %use for phase mask
            %phase2=gpuArray(phase2);

%             if settings.autocontrast.on
%                 phase2=imfilter(phase2, fspecial('gaussian',settings.autocontrast.blurrradius));
%                 phase2=autocontrast(phase2,settings.autocontrast.sigma);
%             end
            
            if settings.thresholdmode == 1
                if i==1 && j==1
                    s1value=settings.thresholdinterval.default;
                    settings.edgemethod='threshold particle variation';
                    s1value2=edge_sobel_canny(phase2,[settings.particlevariation.default settings.thresholdinterval.default], [1 1], [1000 1000], settings,phasefiles2,workingdir);
                    waitfor(s1value2);
                    settings.particlevariation2.default=round(s1value2(1));
                    settings.thresholdinterval2.default=round(s1value2(2));
                    m=0;
                end
                threshold=find_thresholdv1_2(phase2, round(settings.particlevariation2.default), round(settings.thresholdinterval2.default),1,0);
                phasefill2=(phase2 > threshold);
            end
            
            if settings.thresholdmode == 2
                m=1;
                if i==1 && j==1
                    settings.edgemethod='canny';
                    if isfield(settings, 'canny2')
                        s1value2=edge_sobel_canny(phase2,[settings.canny2.low settings.canny2.high], [settings.canny2.low*0.1 settings.canny2.high*0.1], [settings.canny2.low*2 settings.canny2.high*2], settings,phasefiles2,workingdir);
                    else
                        s1value2=edge_sobel_canny(phase2,[settings.canny.low settings.canny.high], [settings.canny.low*0.1 settings.canny.high*0.1], [settings.canny.low*2 settings.canny.high*2], settings,phasefiles2,workingdir);
                    end
                    waitfor(s1value2);
                    settings.canny2.low=s1value2(1);
                    settings.canny2.high=s1value2(2);
                    m=0;
                end

                %phasefill=imopen(imfill(imdilate(edge(phase, 'canny', [settings.canny.low settings.canny.high]), settings.structure), 'holes'),settings.structure2); %detect edge, dilate mask, fill mask holes, remove border particles
                phasefill2=edge(phase2, 'canny', [settings.canny2.low settings.canny2.high]); %detect edge, dilate mask, fill mask holes, remove border particles
            end
            
            if settings.thresholdmode==3
                m=1;
                if i==1 && j==1
                    settings.edgemethod='sobel';
                    if isfield(settings, 'sobel2')
                        s1value2=edge_sobel_canny(phase2,settings.sobel2.threshold,settings.sobel2.threshold*0.1,settings.sobel2.threshold*10,settings,phasefiles2,workingdir);
                    else
                        s1value2=edge_sobel_canny(phase2,settings.sobel.threshold,settings.sobel.threshold*0.1,settings.sobel.threshold*10,settings,phasefiles2,workingdir);
                    end
                    waitfor(s1value2);
                    settings.sobel2.threshold=s1value2;
                    m=0;
                end
                %phasefill=imopen(imfill(imdilate(edge(phase, 'sobel', settings.sobel.threshold), settings.structure), 'holes'),settings.structure2); %detect edge, dilate mask, fill mask holes, remove border particles
                phasefill2=edge(phase2, 'sobel', settings.sobel2.threshold);
            end
            
            if settings.thresholdmode==4
                if isfield(settings,'thresholdpixelvalue')
                    s1value=settings.thresholdpixelvalue;
                else
                    s1value=round(mean(mean(phase)));
                end
                
                if i==1 && j==1
                    %display(settings.structure2);
                    settings.edgemethod='threshold value';
                    if isfield(settings, 'thresholdpixelvalue2')
                        s1value2=edge_sobel_canny(phase2,settings.thresholdpixelvalue2,min(min(phase2)),max(max(phase2)),settings,phasefiles2,workingdir);
                    else
                        s1value2=edge_sobel_canny(phase2,s1value,min(min(phase2)),max(max(phase2)),settings,phasefiles2,workingdir);
                    end
                    waitfor(s1value2);
                    settings.thresholdpixelvalue2=round(s1value2);
                    m=0;
                end
                
                phasefill2=phase > settings.thresholdpixelvalue2;
            end
                        
            if settings.imdilate
                phasefill2=imdilate(phasefill2, settings.structure);
            end
            
            if settings.thresholdmode ~= 4
                phasefill2=imfill(phasefill2,'holes');
            end
                
            if settings.imopen
                phasefill2=imopen(phasefill2, settings.structure2);
            end
            
            if settings.imclose
                phasefill2=imclose(phasefill2,settings.structure2);
            end
            
            %figure;
            %imshow(phasefill2);
            phasetemp=phasefill+phasefill2;
            phasefill=ceil(phasetemp/max(max(phasetemp)));
        end
        
        %phasefill=imread(strcat(workingdir,'/timelapse6wellxy12t33-gfp_mask.tif'));
        phasefilllabel=bwlabel(phasefill);
        
        if settings.showmasks
            if i==1
                window1=figure('Position', [300 300 1000 1000]);
            end
            
            figure(window1)
            
            %                         assignin('base','fp1',fp1);
            %                         assignin('base','phasefill',phasefill);
            %
            %IMG_temp=double(immultiply(uint16(fp1),uint16(phasefill)+1));
            IMG_temp=double(fp1);
            
            lowfactor=3;
            highfactor=4;
            IMG_avg=mean2(IMG_temp);
            IMG_std=std2(IMG_temp);
            
            IMG_temp=(IMG_temp-IMG_avg+lowfactor*IMG_std)/(IMG_avg+highfactor*IMG_std);
            IMG_map=IMG_temp > (IMG_avg+highfactor*IMG_std);
            iIMG_map=1-IMG_map;
            IMG_temp=iIMG_map.*IMG_temp+IMG_map;
            
            phasefillrgb(:,:,1)=IMG_temp+double(phasefill);
            phasefillrgb(:,:,2)=IMG_temp;
            phasefillrgb(:,:,3)=IMG_temp;
            
            imshow(phasefillrgb,[],'InitialMagnification','fit');
            
            %impreview=immultiply(uint16(fp1),uint16(phasefill)+1);
            %imshow(impreview, [min(min(impreview)) 0.5*max(max(impreview))]);
            
            if settings.handpickmasks
                satisfied='No';
                while(strcmp(satisfied, 'No'))
                    ptsx=[];
                    ptsy=[];
                    
                    if settings.showmasks && settings.labelparticlenumbers
                        figure(window1)
                        numberofparticles=max(max(phasefilllabel));
                        for k=1:1:numberofparticles
                            [r,c] = find(phasefilllabel==k);    %extract ROIs
                            rc{k} = [r c];      %save ROIs to cell array (not necessary to use cell array)
                            text(rc{k}(1,2),rc{k}(1,1),num2str(k),'fontsize',20,'color',[0,0,1]);
                        end
                    end
                    
                    title('Select masks to remove');
                    [ptsx, ptsy]=getpts(window1);
                    ptsx=uint16(ptsx);
                    ptsy=uint16(ptsy);
                    
                    if length(ptsx) > 0
                        for n=1:length(ptsx)
                            particletoremovenumber=phasefilllabel(ptsy(n),ptsx(n));
                            %display(['removing particle ' num2str(particletoremovenumber)]);
                            particletoremoveIMG=phasefilllabel==particletoremovenumber;
                            phasefilllabel=imsubtract(phasefilllabel,particletoremoveIMG*particletoremovenumber);
                        end
                    end
                    phasefilllabel=bwlabel(phasefilllabel);
                    phasefill=phasefilllabel>0;
                    
                    phasefillrgb(:,:,1)=IMG_temp+double(phasefill);
                    phasefillrgb(:,:,2)=IMG_temp;
                    phasefillrgb(:,:,3)=IMG_temp;
                    imshow(phasefillrgb,[],'InitialMagnification','fit');
                    
                    %impreview=immultiply(uint16(fp1),uint16(phasefill)+1);
                    %imshow(impreview, [min(min(impreview)) 0.5*max(max(impreview))]);
                    
                    title('Masks removed!');
                    satisfied=questdlg('Satisfied with the masks? ', 'Dialog', 'Yes', 'No', 'No');
                end
            end
        end
        
        %settings.savemasks=1;
        if settings.savemasks
            newFileName=char(strrep(phasefiles{i,1}, '.', '_mask.'));
            imwrite(phasefill,strcat(workingdir,'/',newFileName), 'tif','Compression','none');
        end
        
        avgbackground1=0;
        avgbackground2=0;
        if settings.backsub
            avgbackground1=sum(sum(immultiply(fp1,uint16(1-phasefill))))/sum(sum(1-phasefill)); %compute the background using an inverted mask of phasefill (mask still includes border objects)
            if not(isempty(settings.fluorsuffix2))
                avgbackground2=sum(sum(immultiply(fp2,uint16(1-phasefill))))/sum(sum(1-phasefill)); %compute the background using an inverted mask of phasefill (mask still includes border objects)
            end
        end

        %%%%%%%%%%%%%%%%%%%%%
        % Analyze particles %
        %%%%%%%%%%%%%%%%%%%%%
        settings.doanalysis=1;
        if settings.doanalysis
        numberofparticles=max(max(phasefilllabel));
        intensitysum=0;
        intensitysum2=0;
        intensitysum3=0;
        intensitysum_noratio=0;
        intensitysum_noratio_bsub=0;
        areasum=0;
        %area=0;
        numberofparticlesfiltered=0;
        intensitysubarray=[];
        individualratio=[];

        for k=1:1:numberofparticles
            [r,c] = find(phasefilllabel==k);    %extract ROIs
            rc{k} = [r c];      %save ROIs to cell array (not necessary to use cell array)
            
            %Changes by Henry
            pH{k} = imcrop(myPhase,[min(rc{k}(:,2))-15, min(rc{k}(:,1))-15, max(rc{k}(:,2))-min(rc{k}(:,2)) + 60, max(rc{k}(:,1))-min(rc{k}(:,1)) + 60]);
            %End Of changes
            
            p0{k}=impixel(phase, rc{k}(:,2), rc{k}(:,1));  %save phase pixels values in cell array (not necessary to use cell array)
            p1{k}=impixel(fp1, rc{k}(:,2), rc{k}(:,1));  %save pixels values in cell array (not necessary to use cell array)
        end

        %label particle numbers
        if settings.showmasks && settings.labelparticlenumbers
            figure(window1)
            for m=1:numberofparticles
                text(rc{m}(1,2),rc{m}(1,1),num2str(m),'fontsize',20,'color',[0,0,1]);
            end
        end


        for k=1:1:numberofparticles
            intensity1=sum(p1{k}(:,1));
            area=size(p1{k},1);
            
            if not(isempty(settings.fluorsuffix2))
                p2{k}=impixel(fp2, rc{k}(:,2), rc{k}(:,1));  %save pixels values in cell array (not necessary to use cell array)
                intensity2=sum(p2{k}(:,1));
            end
            
            if settings.backsub && not(isempty(settings.fluorsuffix2))
                ratio=(intensity1-(avgbackground1*area))/(intensity2-(avgbackground2*area));
                ratio2=(intensity1-(avgbackground1*area))/area;
                ratio3=(intensity2-(avgbackground2*area))/area;
            elseif not(isempty(settings.fluorsuffix2))
                ratio=intensity1/intensity2;
                ratio2=intensity1/area;
                ratio3=intensity2/area;
            elseif settings.backsub
                ratio=intensity1/area-avgbackground1;
                ratio2=ratio;
                ratio3=ratio;
            else
                ratio=intensity1/area;
                ratio2=ratio;
                ratio3=ratio;
            end
          
            if ratio > settings.arbitrarythreshold
                abovethreshold=1;
            elseif ratio < settings.arbitrarythreshold
                abovethreshold=0;
            end
            
            if area(1) >= settings.minimumarea && area(1) <= settings.maximumarea && not(isempty(settings.fluorsuffix2))
                %note: values below background for either fluor1 or fluor2
                %will be excluded
                %ALSO, ONLY fluor2/area > 1 WILL BE INCLUDED!!!!
                %to force inclusion, settings.includebelowbackground must be set = 1
                if (((intensity1-(avgbackground1*area)) > 0 ) && ((intensity2-(avgbackground2*area)) > 0 ) && ( (intensity2/area-avgbackground2) > 1) ) || settings.includebelowbackground
                    results=cat(1,results,[k (intensity1-(avgbackground1*area)) (intensity2-(avgbackground2*area)) area(1) ratio (intensity1/area-avgbackground1) (intensity2/area-avgbackground2)]);
                    outputheading={'cell number', settings.fluorsuffix1, settings.fluorsuffix2, 'pixel area', strcat(settings.fluorsuffix1, '/', settings.fluorsuffix2), strcat(settings.fluorsuffix1, '/', 'area'), strcat(settings.fluorsuffix2, '/', 'area')};
                    outputheading_fileavgs={'filename', ['avg ' settings.fluorsuffix1,'/area'], ['avg ' settings.fluorsuffix2,'/area'], ['avg ', settings.fluorsuffix1,'/',settings.fluorsuffix2], 'avg area', 'numberofparticlesfiltered','std(individualratio)/sqrt(# individualratio)','intensitysum_noratio (no background subtraction)','std(intensitysum_noratio)','intensitysum_noratio bsub','area above threshold'};
                    numberofparticlesfiltered=numberofparticlesfiltered+1;
                    intensitysum=intensitysum+ratio;
                    intensitysum2=intensitysum2+ratio2;
                    intensitysum3=intensitysum3+ratio3;
                    intensitysum_noratio=intensitysum_noratio+intensity1;
                    intensitysum_noratio_bsub=intensitysum_noratio_bsub+intensity1-(avgbackground1*area);
                    intensitysubarray=cat(1,intensitysubarray,intensity1);
                    areasum=areasum+area;
                    individualratio=cat(1,individualratio, ratio);
                end
            elseif area(1) >= settings.minimumarea && area(1) <= settings.maximumarea
                if ((intensity1-(avgbackground1*area)) > 0 ) || settings.includebelowbackground
                    if settings.programmode==1
                        results=cat(1,results,[k (intensity1-(avgbackground1*area)) area(1) ratio abovethreshold]);
                        outputheading={'cell number', settings.fluorsuffix1, 'pixel area', strcat(settings.fluorsuffix1, '/area')};
                        
                    elseif settings.programmode==2
                        results_local_temp=ptc_localization(rc{k}, fp1);
                        if ~isnan(results_local_temp(1))
                            results=cat(1,results,[k (intensity1-(avgbackground1*area)) area(1) ratio abovethreshold results_local_temp(1) results_local_temp(2) results_local_temp(3)]);
                            outputheading={'cell number', settings.fluorsuffix1, 'pixel area', strcat(settings.fluorsuffix1, '/area'), 'unknown', 'peaktobackground', 'stdevtobackground', 'distance from centroid'};
                            
                            %Henry Line
                            localResults = cat(1, localResults, [k results_local_temp(4) results_local_temp(5) results_local_temp(6) results_local_temp(1) rc{k}(1,2) rc{k}(1,1)]);
                            localOutputHeading = {'cell number', 'fit peak', 'fit position', 'fit width', 'peaktobackground' 'x pos', 'y pos'};
                            pictureArray = cat(1, pictureArray, pH{k});
                            myFileNames = cat(1,myFileNames, fluorfiles1{i,1});
                            %End of Henry Lines
                            
                        end
                        
                    elseif settings.programmode==3
                        results_local_temp=ptc_celldimensions(rc{k}, phase);
                        if ~isnan(results_local_temp(1))
                            results=cat(1,results,[k (intensity1-(avgbackground1*area)) area(1) ratio abovethreshold results_local_temp(2) results_local_temp(3)]);
                            outputheading={'cell number', settings.fluorsuffix1, 'pixel area', strcat(settings.fluorsuffix1, '/area'), 'MinorAxisLength', 'MajorAxisLength'};
                        end
                    else
                        
                    end
                    outputheading_fileavgs={'filename', ['avg ' settings.fluorsuffix1,'/area'], ['avg ', settings.fluorsuffix1,'/area'],['avg ', settings.fluorsuffix1,'/area'], 'avg area', 'numberofparticlesfiltered','std(individualratio)/sqrt(# individualratio)','intensitysum_noratio (no background subtraction)','std(intensitysum_noratio)','intensitysum_noratio bsub','area above threshold'};
                    numberofparticlesfiltered=numberofparticlesfiltered+1;
                    intensitysum=intensitysum+ratio;
                    intensitysum2=intensitysum2+ratio2;
                    intensitysum3=intensitysum3+ratio3;
                    intensitysum_noratio=intensitysum_noratio+intensity1;
                    intensitysum_noratio_bsub=intensitysum_noratio_bsub+intensity1-(avgbackground1*area);
                    intensitysubarray=cat(1,intensitysubarray,intensity1);
                    areasum=areasum+area;
                    individualratio=cat(1,individualratio, ratio);
                end
            else
                %outputheading='';
                %outputheading_fileavgs='';
            end
            individualratioarray{i,1}=individualratio;
            intensityarray{i,1}=intensitysubarray;
        end
        
        if not(isempty(settings.fluorsuffix2))
            resultscol=5;
        else
            resultscol=4;
        end
        
        if not(isempty(settings.fluorsuffix2))
            output=strcat('average ', settings.fluorsuffix1,'/',settings.fluorsuffix2);
        else
            output=strcat('average ', settings.fluorsuffix1,'/area');
        end
        
        disp([fluorfiles1{i,1} ' ' output ' ' num2str(intensitysum/numberofparticlesfiltered) ' ' num2str(numberofparticlesfiltered) ' ' num2str(intensitysum_noratio) ' ' num2str(intensitysum_noratio_bsub)]);
        
        if numberofparticlesfiltered > 0
            fileaveragearray{j-1+i,1}=fluorfiles1{i,1};
            fileaveragearray{j-1+i,2}=intensitysum2/numberofparticlesfiltered;
            fileaveragearray{j-1+i,3}=intensitysum3/numberofparticlesfiltered;
            fileaveragearray{j-1+i,4}=intensitysum/numberofparticlesfiltered;
            fileaveragearray{j-1+i,5}=areasum/numberofparticlesfiltered;
            fileaveragearray{j-1+i,6}=numberofparticlesfiltered;
            fileaveragearray{j-1+i,7}=std(individualratio)/(length(individualratio))^0.5;
            fileaveragearray{j-1+i,8}=intensitysum_noratio;
            fileaveragearray{j-1+i,9}=std(intensitysubarray)/(length(intensitysubarray))^0.5;
            fileaveragearray{j-1+i,10}=intensitysum_noratio_bsub;
            fileaveragearray{j-1+i,11}=areasum;
        else
            fileaveragearray{j-1+i,11}=areasum;
        end
        end        
        clear intensitysum;
        avgbackgroundarray1(i)=avgbackground1;
        avgbackgroundarray2(i)=avgbackground2;
    end
    %close(progressbar);
    
    if not(isempty(results))
        resultscellarray{1,j}=[results];
        resultscellarray{2,j}=mean(resultscellarray{1,j}(:,resultscol));
        
        if settings.displaycellsizehistogram
       
            figure;
            bins=0:ceil((max(max(results(:,resultscol-1)))-min(min(results(:,resultscol-1))))/50):ceil(max(max(results(:,resultscol-1))));
            histnorm(results(:,resultscol-1),bins);
            title('cell sizes used');
 
        end
        
        if settings.displayintensityhistogram
            %             if ceil(max(results(:,resultscol))) > 1
            %                 bins=0:ceil((max(max(results(:,resultscol)))-min(min(results(:,resultscol))))/50):ceil(max(results(:,resultscol)));
            %             else
            %                 bins=0:(max(max(results(:,resultscol)))-min(min(results(:,resultscol))))/50:ceil(max(results(:,resultscol)));
            %             end
            bins=0:(max(max(results(:,resultscol)))-min(min(results(:,resultscol))))/50:ceil(max(results(:,resultscol)));
            bins
            display(num2str(length(results(:,resultscol))));
            if length(results(:,resultscol)) > 0
                figure;
                histnorm(results(:,resultscol),bins);
            end
            title('intensity distribution');
        end
        
        if not(isempty(settings.fluorsuffix2))
            resultscellarray{3,j}=mean(resultscellarray{1,j}(:,resultscol+1));
            resultscellarray{4,j}=mean(resultscellarray{1,j}(:,resultscol+2));
            resultscellarray{5,j}=mean(resultscellarray{1,j}(:,resultscol-1));
            resultscellarray{6,j}=length(resultscellarray{1,j}(:,resultscol));
            resultscellarray{7,j}=std(resultscellarray{1,j}(:,resultscol))/(length(resultscellarray{1,j}(:,resultscol)))^0.5;
            resultscellarray{8,j}=std(resultscellarray{1,j}(:,resultscol+1))/(length(resultscellarray{1,j}(:,resultscol+1)))^0.5;
            resultscellarray{9,j}=std(resultscellarray{1,j}(:,resultscol+2))/(length(resultscellarray{1,j}(:,resultscol+2)))^0.5;
            resultscellarray{10,j}=avgbackgroundarray1;
            resultscellarray{11,j}=avgbackgroundarray2;
            
            %label results rows
            resultscellarray{1,settings.foldersuffixend+1}='indiv. cell data';
            resultscellarray{2,settings.foldersuffixend+1}=strcat('average', ' ', settings.fluorsuffix1, '/', settings.fluorsuffix2);
            resultscellarray{3,settings.foldersuffixend+1}=strcat('average', ' ', settings.fluorsuffix1, '/area');
            resultscellarray{4,settings.foldersuffixend+1}=strcat('average', ' ', settings.fluorsuffix2, '/area');
            resultscellarray{5,settings.foldersuffixend+1}='average area';
            resultscellarray{6,settings.foldersuffixend+1}='number of cells';
            resultscellarray{7,settings.foldersuffixend+1}=strcat('stderr', ' ', settings.fluorsuffix1, '/', settings.fluorsuffix2);
            resultscellarray{8,settings.foldersuffixend+1}=strcat('stderr', ' ', settings.fluorsuffix1, '/area');
            resultscellarray{9,settings.foldersuffixend+1}=strcat('stderr', ' ', settings.fluorsuffix2, '/area');
            resultscellarray{10,settings.foldersuffixend+1}='avgbackground1';
            resultscellarray{11,settings.foldersuffixend+1}='avgbackground2';
            
        else
            resultscellarray{3,j}=mean(resultscellarray{1,j}(:,resultscol-1));
            resultscellarray{4,j}=length(resultscellarray{1,j}(:,resultscol));
            resultscellarray{5,j}=std(resultscellarray{1,j}(:,resultscol))/(length(resultscellarray{1,j}(:,resultscol)))^0.5;
            resultscellarray{6,j}=sum(resultscellarray{1,j}(:,resultscol+1))/length(resultscellarray{1,j}(:,resultscol));
            resultscellarray{7,j}=avgbackgroundarray1;
            resultscellarray{8,j}=avgbackgroundarray2;
            
            if settings.programmode==2
                %Henry Change
                resultscellarray{9,j}=[localResults];
                resultscellarray{10,j}=mean(resultscellarray{1,j}(:,6));
                resultscellarray{11,j}=mean(resultscellarray{9,j}(:,4));
                resultscellarray{12,j}=mean(resultscellarray{9,j}(:,2));
                resultscellarray{13,j}=mean(resultscellarray{9,j}(:,3));
                %End of Change
            end
            
            %label results rows
            resultscellarray{1,settings.foldersuffixend+1}='indiv. cell data';
            resultscellarray{2,settings.foldersuffixend+1}=strcat('average', ' ', settings.fluorsuffix1, '/area');
            resultscellarray{3,settings.foldersuffixend+1}='average area';
            resultscellarray{4,settings.foldersuffixend+1}='number of cells';
            resultscellarray{5,settings.foldersuffixend+1}=strcat('stderr', ' ', settings.fluorsuffix1, '/area');
            resultscellarray{6,settings.foldersuffixend+1}=strcat('fraction of cells above arbitrary threshold: ', num2str(settings.arbitrarythreshold));
            resultscellarray{7,settings.foldersuffixend+1}='avgbackground1';
            resultscellarray{8,settings.foldersuffixend+1}='avgbackground2';
            
            if settings.programmode==2
                %Henry Change
                resultscellarray{9,settings.foldersuffixend+1}='indiv. local cell data';
                resultscellarray{10,settings.foldersuffixend+1}='Avg peakToBackground';
                resultscellarray{11,settings.foldersuffixend+1}='Avg Fit Width';
                resultscellarray{12,settings.foldersuffixend+1}='Avg Fit Amplitude';
                resultscellarray{13,settings.foldersuffixend+1}='Avg Fit Position';
                %End of Henry Changes
            end
        end
        
        if not(isempty(settings.foldername)) %rename resultscellarray to 'folder name' if it is specificed
            tempname=settings.foldername;
            tempname=regexprep(tempname,'-','');
            tempname=regexprep(tempname,' ','_');
            tempname=regexprep(tempname,'\.','dot');
        else
            tempname=dirname;
        end
        
        disp(['folder ' tempname ' average: ' num2str(mean(results(:,resultscol))) ' stdev: ' num2str(std(results(:,resultscol)))]);

        assignin('base', ['var_' tempname], resultscellarray);
        assignin('base', ['var_' tempname '_fileavgs'], fileaveragearray);
        assignin('base', ['var_' tempname '_settings'], settings);
        
        if not(isempty(settings.fluorsuffix2))
            clear intensity2 fluorfiles2 avgbackground2 p2 fp2
        end
    end
end

if exist('outputheading')
    assignin('base', 'outputheading', outputheading);
    assignin('base', 'outputheading_fileavgs', outputheading_fileavgs);
end

%Henry Change
if exist('localOutputHeading')
    assignin('base', 'localOutputHeading', localOutputHeading);
end
%End of Changes
ptcoutput=settings;
%disp('Done!');
%close(preview);

%find where current matlab files are
pathelements=strsplit(mfilename('fullpath'),'/');
path=[];
for i=2:length(pathelements)-2;
    path=[path '/' pathelements{i}];
end


%Changes by Henry
if settings.programmode==2
    outputWindow(results, localResults, pictureArray, myFileNames);
end
%End of changes


%play sound
%Changed by Henry
%Old Line: 
%sound(wavread([path '/shared/Glass.wav']),44100);
sound(audioread([path '/shared/Glass.wav']),44100);
%End of changes



if settings.clearvars
    clear m slider1 slider2 s1value s2value pushbutton1 dirname;
    clear individualratio individualratioarray;
    clear suffix results resultscellarray workingdir j area avgbackground1 avgbackground2 fluorfiles1 fluorfiles2 phasefiles c fp1 fileinfo i intensity1 p1 k numberoffiles numberofparticles phase phasefill phasefilllabel phasefillnoborder labeledimage progressbar r ratio rc se0 se90 se resultscol fileaveragearray numberofparticlesfiltered;
    clear phase2 phase2files phasefiles2 phasefill2 phasetemp;
    clear intensitysum_noratio intensitysum_noratio_bsub areasum IMGnumber slider3;
end

end

