%this will filter out by cy5/cell area intensity
%will compute new peak to background intensity
%2018-05-07
%AS and HA
%
dataraw=var_1_uM_LL37;
data=dataraw{1,1};
threshold=100;
valuesoverthreshold=[];

for i=1:length(data)
    if data(i,4) > threshold
       %display([num2str(i),' ', num2str(data(i,4))]); 
       valuesoverthreshold=cat(1, valuesoverthreshold, data(i,6));
    end
end

average=mean(valuesoverthreshold);
average_stderr=std(valuesoverthreshold)/length(valuesoverthreshold);