
%varagarin format: edge_sobel_canny(IMG, svalue(1), min, max);
%adaptation from cell_velocity_1.43
%v1.1 3/22/12 various changes to improve efficiency, speed
        %included additonal conditional slider for multiple files; had to
        %accomodate varvargin==6 as well
%v1.2 got rid of user-defined initial min/max values. calculate min/max from inital
%value instead
%v1.3 program is passed settings instead of just 'sobel/canny'
%Correct usage is: edge_sobel_canny(IMG, [value_init], [value_low], [value_high], settings, [files], workingdir)
%syntax for 4 arguments: (IMG, svalue initial, low, high)
%syntax for 5 arguments: (IMG, svalue initial, low, high, settings)
%syntax for 7 arugments: (IMG, svalue initial, low, high, settings [files], workingdir)
%%AS 1/30/12
%pctGUI1.0.120829 - added syntax comments
%2018-04-25 changes by Henry: 
%-updated instances of "imfilter" to "imgaussfilt"


function varargout = edge_sobel_canny(varargin)
% EDGE_SOBEL_CANNY MATLAB code for edge_sobel_canny.fig
%      EDGE_SOBEL_CANNY, by itself, creates a new EDGE_SOBEL_CANNY or raises the existing
%      singleton*.
%
%      H = EDGE_SOBEL_CANNY returns the handle to a new EDGE_SOBEL_CANNY or the handle to
%      the existing singleton*.
%
%      EDGE_SOBEL_CANNY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EDGE_SOBEL_CANNY.M with the given input arguments.
%
%      EDGE_SOBEL_CANNY('Property','Value',...) creates a new EDGE_SOBEL_CANNY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before edge_sobel_canny_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to edge_sobel_canny_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help edge_sobel_canny

% Last Modified by GUIDE v2.5 26-Apr-2018 13:06:08

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @edge_sobel_canny_OpeningFcn, ...
                   'gui_OutputFcn',  @edge_sobel_canny_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});

end
% End initialization code - DO NOT EDIT



% --- Executes just before edge_sobel_canny is made visible.
function edge_sobel_canny_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to edge_sobel_canny (see VARARGIN)

% Choose default command line output for edge_sobel_canny

if (length(varargin) < 4) || (length(varargin) == 6)
   error('Incorrect number of arguments. Correct usage is: edge_sobel_canny(IMG, [value_init], [value_low], [value_high], ''sobel/canny'', [files], workingdir). Exiting....');
end
%display ([num2str(length(varargin)) ';' num2str(size(varargin{1})) ';' num2str(size(varargin{2})) ';' num2str(size(varargin{3})) ';' num2str(size(varargin{4}))]);

%%%%%%%%%%%%%%
% defaults   %
%%%%%%%%%%%%%%
%handles.metricdata.close=0;

%load variables from varargin
handles.metricdata.IMG=varargin{1};
handles.metricdata.svalue=varargin{2};
handles.metricdata.low=varargin{3};
handles.metricdata.high=varargin{4};

if length(varargin) > 4
    handles.metricdata.settings=varargin{5};
end

%%%%%%%%%%%%
%replaced by previous section on 2012-07-17
% if length(varargin) > 4
%     settings=varargin{5};
%     handles.metricdata.settings.edgemethod=settings.edgemethod;
%     handles.metricdata.settings.invert=settings.invert;
%     handles.metricdata.settings.thresholdvalue.dilate=settings.thresholdvalue.dilate;
%     handles.metricdata.settings.structure=settings.structure;
%     handles.metricdata.settings.structure2=settings.structure2;
%     if handles.metricdata.settings.invert
%         handles.metricdata.IMG=imcomplement(handles.metricdata.IMG);
%     end
%     handles.metricdata.settings.imdilate=settings.imdilate;
%     handles.metricdata.settings.imopen=settings.imopen;
%     handles.metricdata.settings.imclose=settings.imclose;
%     
%     handles.metricdata.settings.autocontrast.on=settings.autocontrast.on;
%     handles.metricdata.settings.autocontrast.blurrradius=settings.autocontrast.blurrradius;
%     handles.metricdata.settings.autocontrast.sigma=settings.autocontrast.sigma;
% 
% else
%     handles.metricdata.settings.edgemethod='sobel';
%     handles.metricdata.settings.structure=strel('disk',3);
%     handles.metricdata.settings.thresholdvalue.dilate=1;
% end
%%%%%%%%%%%%

%ignore user-defined min/max; set relative min/max
handles.metricdata.low(1)=handles.metricdata.svalue(1)*0.1;
handles.metricdata.high(1)=handles.metricdata.svalue(1)*10;

%load sliders, show images
set(handles.edit1, 'String', sprintf('%.5f',handles.metricdata.low(1)));
set(handles.edit2, 'String', sprintf('%.5f',handles.metricdata.high(1)));
set(handles.slider1, 'Min', handles.metricdata.low(1));
set(handles.slider1, 'Max', handles.metricdata.high(1));
set(handles.slider1, 'Value', handles.metricdata.svalue(1));
set(handles.slider2, 'Min', handles.metricdata.low(1)/5);
set(handles.slider2, 'Max', handles.metricdata.high(1)*5);
set(handles.slider2, 'Value', handles.metricdata.svalue(1));
set(handles.text1, 'String', sprintf('%.5f',handles.metricdata.svalue(1)));

if length(varargin)>= 5
    if strcmp(handles.metricdata.settings.edgemethod,'canny') || strcmp(handles.metricdata.settings.edgemethod,'threshold particle variation')
        if length(handles.metricdata.svalue)==2
            if length(handles.metricdata.low)==2
                if length(handles.metricdata.high)==2
                    if (handles.metricdata.svalue(2) > handles.metricdata.svalue(1))
                        set(handles.slider4,'Visible','on');
                        set(handles.slider5,'Visible','on');
                        set(handles.text11,'Visible','on');
                        set(handles.text12,'Visible','on');
                        set(handles.text13,'Visible','on');
                        set(handles.text14,'Visible','on');
                        set(handles.text15,'Visible','on');
                        set(handles.text16,'Visible','on');
                        set(handles.edit3,'Visible','on');
                        set(handles.edit4,'Visible','on');

                        %ignore user-defined min/max; set relative min/max
                        handles.metricdata.low(2)=handles.metricdata.svalue(2)*0.1;
                        handles.metricdata.high(2)=handles.metricdata.svalue(2)*10;
                        
                        set(handles.edit3, 'String', sprintf('%.5f',handles.metricdata.low(2)));
                        set(handles.edit4, 'String', sprintf('%.5f',handles.metricdata.high(2)));
                        set(handles.slider4, 'Min', handles.metricdata.low(2));
                        set(handles.slider4, 'Max', handles.metricdata.high(2));
                        set(handles.slider4, 'Value', handles.metricdata.svalue(2));
                        set(handles.slider5, 'Min', handles.metricdata.low(2)*5);
                        set(handles.slider5, 'Max', handles.metricdata.high(2)/5);
                        set(handles.slider5, 'Value', handles.metricdata.svalue(2));
                        set(handles.text11, 'String', sprintf('%.5f',handles.metricdata.svalue(2)));
                    else
                        error('svalue(2) must be greater than svalue(1).Exiting...');
                    end
                end
            end
        end
    elseif strcmp(handles.metricdata.settings.edgemethod,'threshold value')
        display('threshold value in effect. construction in progress... you need to activate the correct sliders');
    end
end
guidata(hObject, handles);

if (length(varargin) == 4) || (length(varargin) == 5)
    %display(['handles: ' num2str(handles)]);
    %IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure, handles);
    IMG=preview(handles);
    imshow(IMG, 'Parent',handles.axes1, 'DisplayRange',[]);
    imshow(handles.metricdata.IMG,'Parent',handles.axes2,'DisplayRange',[]);
    %imshow(imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes'),'Parent',handles.axes1);

elseif length(varargin) == 7
    handles.metricdata.files=varargin{6};
    handles.metricdata.workingdir=varargin{7};
    if length(handles.metricdata.files) < 2
        disp('File list not greater than 1. Not bringing up file slider...');
    else
        set(handles.slider3,'Visible','on');
        set(handles.text10,'Visible','on');
        set(handles.text10,'String',['File preview: 1 of ' num2str(length(handles.metricdata.files))]);
        set(handles.slider3,'Min',1);
        set(handles.slider3,'Max',length(handles.metricdata.files));
        set(handles.slider3,'Value',1);
        sliderstepsize=1/(length(handles.metricdata.files));
        set(handles.slider3,'SliderStep',[sliderstepsize sliderstepsize]);
    end
    %show first image in file (ignore varargin{1})
    handles.metricdata.IMG=imread(strcat(handles.metricdata.workingdir,'/',handles.metricdata.files{1,1}));
    %handles.metricdata.IMG=gpuArray(handles.metricdata.IMG);
    if handles.metricdata.settings.invert
        handles.metricdata.IMG=imcomplement(handles.metricdata.IMG);
    end
    imshow(handles.metricdata.IMG,'Parent',handles.axes2,'DisplayRange',[]);
    %IMG=imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes');
    %IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure, handles);
    IMG=preview(handles);
    
    imshow(IMG,'Parent',handles.axes1);
end


handles.output = hObject;
guidata(hObject, handles);

%wait until done button is pressed
uiwait();
%handles.output=handles.metricdata.svalue;
%guidata(hObject, handles);
% UIWAIT makes edge_sobel_canny wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = edge_sobel_canny_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
%uiwait();
%guidata(hObject, handles);
%handles.output=handles.metricdata.x;
varargout{1} = handles.output;
%varargout{2} = handles.output2;
close;
%if handles.metricdata.close
%    close all;
%end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
input=get(hObject, 'Value');
acceptinput=0;
if length(handles.metricdata.svalue) ==1
    acceptinput=1;
elseif length(handles.metricdata.svalue) == 2
    if input < handles.metricdata.svalue(2)
        acceptinput=1;
    end
end

if acceptinput
    handles.metricdata.svalue(1)=input;
    set(handles.text1, 'String', sprintf('%.5f',handles.metricdata.svalue(1)));
    disp(num2str(handles.metricdata.svalue(1)));
    set(handles.slider2,'Min',handles.metricdata.svalue(1)*0.5);
    set(handles.slider2,'Max',handles.metricdata.svalue(1)*1.5);
    set(handles.slider2,'Value',handles.metricdata.svalue(1));
    set(handles.edit1, 'String',sprintf('%.5f',handles.metricdata.svalue(1)*0.1));
    set(handles.edit2, 'String',sprintf('%.5f',handles.metricdata.svalue(1)*2));
    %IMG=imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes');
    %IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure,handles);
    IMG=preview(handles);
    imshow(IMG,'Parent',handles.axes1);
    drawnow;
else
    set(handles.slider1,'Value',handles.metricdata.svalue(1));
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
input=get(hObject, 'Value');
acceptinput=0;
if length(handles.metricdata.svalue) ==1
    acceptinput=1;
elseif length(handles.metricdata.svalue) == 2
    if input < handles.metricdata.svalue(2)
        acceptinput=1;
    end
end

if acceptinput
    handles.metricdata.svalue(1)=get(hObject, 'Value');
    set(handles.text1, 'String', sprintf('%.5f',handles.metricdata.svalue(1)));
    disp(num2str(handles.metricdata.svalue(1)));
    set(handles.slider1,'Min',handles.metricdata.svalue(1)*0.1);
    set(handles.slider1,'Max',handles.metricdata.svalue(1)*2);
    set(handles.slider1,'Value',handles.metricdata.svalue(1));
    set(handles.edit1, 'String',sprintf('%.5f',handles.metricdata.svalue(1)*0.1));
    set(handles.edit2, 'String',sprintf('%.5f',handles.metricdata.svalue(1)*2));
    %IMG=imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes');
    %IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure,handles);
    IMG=preview(handles);
    imshow(IMG,'Parent',handles.axes1);
    drawnow;
else
    set(handles.slider2,'Value',handles.metricdata.svalue(1));
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function uipanel1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
%input=10^str2double(get(hObject,'String'));
input=str2double(get(hObject,'String'));
if input < handles.metricdata.high(1)
    handles.metricdata.low(1)=input;
    set(handles.slider1, 'Min', handles.metricdata.low(1));
    set(handles.slider2, 'Min', handles.metricdata.low(1));
else
    set(hObject,'String',num2str(handles.metricdata.low(1)));
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
%input=10^str2double(get(hObject,'String'));
input=str2double(get(hObject,'String'));
if input > handles.metricdata.low(1)
    handles.metricdata.high(1)=input;
    set(handles.slider1, 'Max', handles.metricdata.high(1));
    set(handles.slider2, 'Max', handles.metricdata.high(1));
else
    set(hObject,'String',num2str(handles.metricdata.high(1)));
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
handles.metricdata.IMGnumber=round(get(hObject,'Value'));

set(handles.text10,'String',['File preview: ' num2str(handles.metricdata.IMGnumber) ' of ' num2str(length(handles.metricdata.files))]);
handles.metricdata.IMG=imread(strcat(handles.metricdata.workingdir,'/',handles.metricdata.files{handles.metricdata.IMGnumber,1}));
%handles.metricdata.IMG=gpuArray(handles.metricdata.IMG);
if handles.metricdata.settings.invert
    handles.metricdata.IMG=imcomplement(handles.metricdata.IMG);
end
imshow(handles.metricdata.IMG,'Parent',handles.axes2,'DisplayRange',[])%;
%IMG=imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes');
%IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure,handles);
IMG=preview(handles);
imshow(IMG,'Parent',handles.axes1);
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.metricdata.close=1;
handles.output=handles.metricdata.svalue;
display(['your threshold value: ' num2str(handles.metricdata.svalue)]);
guidata(hObject, handles);
uiresume();


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%3/26/12

% --- Executes on slider movement.
function slider4_Callback(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
input=get(hObject, 'Value');
if input > handles.metricdata.svalue(1)
    handles.metricdata.svalue(2)=input;
    set(handles.text11, 'String', sprintf('%.5f',handles.metricdata.svalue(2)));
    disp(num2str(handles.metricdata.svalue(2)));
    set(handles.slider5,'Min',handles.metricdata.svalue(2)*0.5);
    set(handles.slider5,'Max',handles.metricdata.svalue(2)*1.5);
    set(handles.slider5,'Value',handles.metricdata.svalue(2));
    set(handles.edit3, 'String',sprintf('%.5f',handles.metricdata.svalue(2)*0.1));
    set(handles.edit4, 'String',sprintf('%.5f',handles.metricdata.svalue(2)*2));
    %IMG=imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes');
    %IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure,handles);
    IMG=preview(handles);
    imshow(IMG,'Parent',handles.axes1);
    drawnow;
else
    set(handles.slider4,'Value',handles.metricdata.svalue(2));
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider5_Callback(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
input=get(hObject, 'Value');
if input > handles.metricdata.svalue(1)
    handles.metricdata.svalue(2)=input;
    set(handles.text11, 'String', sprintf('%.5f',handles.metricdata.svalue(2)));
    disp(num2str(handles.metricdata.svalue(2)));
    set(handles.slider4,'Min',handles.metricdata.svalue(2)*0.1);
    set(handles.slider4,'Max',handles.metricdata.svalue(2)*2);
    set(handles.slider4,'Value',handles.metricdata.svalue(2));
    set(handles.edit3, 'String',sprintf('%.5f',handles.metricdata.svalue(2)*0.1));
    set(handles.edit4, 'String',sprintf('%.5f',handles.metricdata.svalue(2)*2));
    %IMG=imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes');
    %IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure,handles);
    IMG=preview(handles);
    imshow(IMG,'Parent',handles.axes1);
    drawnow;
else
    set(handles.slider5,'Value',handles.metricdata.svalue(2));
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function slider5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
input=str2double(get(hObject,'String'));
if input < handles.metricdata.high(1)
    handles.metricdata.low(2)=input;
    set(handles.slider4, 'Min', handles.metricdata.low(2));
    set(handles.slider5, 'Min', handles.metricdata.low(2));
else
    set(hObject,'String',num2str(handles.metricdata.low(2)));
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
input=str2double(get(hObject,'String'));
if input > handles.metricdata.low(2)
    handles.metricdata.high(2)=input;
    set(handles.slider4, 'Max', handles.metricdata.high(2));
    set(handles.slider5, 'Max', handles.metricdata.high(2));
else
    set(hObject,'String',num2str(handles.metricdata.high(2)));
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function text1_Callback(hObject, eventdata, handles)
% hObject    handle to text1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of text1 as text
%        str2double(get(hObject,'String')) returns contents of text1 as a double
input=str2double(get(hObject,'String'));
acceptinput=0;
if length(handles.metricdata.svalue) ==1
    acceptinput=1;
elseif length(handles.metricdata.svalue) == 2
    if input < handles.metricdata.svalue(2)
        acceptinput=1;
    end
end

if acceptinput
    handles.metricdata.svalue(1)=input;
    set(handles.slider1, 'Value', handles.metricdata.svalue(1));
    set(handles.slider1,'Min',handles.metricdata.svalue(1)*0.1);
    set(handles.slider1,'Max',handles.metricdata.svalue(1)*2);
    set(handles.edit1, 'String',sprintf('%.5f',handles.metricdata.svalue(1)*0.1));
    set(handles.edit2, 'String',sprintf('%.5f',handles.metricdata.svalue(1)*2));
    set(handles.slider2, 'Value', handles.metricdata.svalue(1));
    set(handles.slider2,'Min',handles.metricdata.svalue(1)*0.5);
    set(handles.slider2,'Max',handles.metricdata.svalue(1)*1.5);
    %IMG=imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes');
    %IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure,handles);
    IMG=preview(handles);
    imshow(IMG,'Parent',handles.axes1);
    drawnow;
else
    set(hObject,'String',num2str(handles.metricdata.svalue(1)));
end
guidata(hObject, handles);

function text11_Callback(hObject, eventdata, handles)
% hObject    handle to text11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of text11 as text
%        str2double(get(hObject,'String')) returns contents of text11 as a double
input=str2double(get(hObject,'String'));
if (input > handles.metricdata.low(2)) && (input < handles.metricdata.high(2)) && (input > handles.metricdata.svalue(1))
    handles.metricdata.svalue(2)=input;
    set(handles.slider4, 'Value', handles.metricdata.svalue(2));
    set(handles.slider4,'Min',handles.metricdata.svalue(2)*0.1);
    set(handles.slider4,'Max',handles.metricdata.svalue(2)*2);
    set(handles.edit3, 'String',sprintf('%.5f',handles.metricdata.svalue(2)*0.1));
    set(handles.edit4, 'String',sprintf('%.5f',handles.metricdata.svalue(2)*2));
    set(handles.slider5, 'Value', handles.metricdata.svalue(2));
    set(handles.slider5,'Min',handles.metricdata.svalue(2)*0.5);
    set(handles.slider5,'Max',handles.metricdata.svalue(2)*1.5);
    
    %IMG=imfill(imdilate(edge(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue), handles.metricdata.settings.structure), 'holes');
    %IMG=preview(handles.metricdata.IMG, handles.metricdata.settings.edgemethod, handles.metricdata.svalue, handles.metricdata.settings.structure,handles);
    IMG=preview(handles);
    imshow(IMG,'Parent',handles.axes1);
    drawnow;
else
    set(hObject,'String',num2str(handles.metricdata.svalue(2)));
end
guidata(hObject, handles);

function IMG=preview(handles)
IMG=[];
IMG_current=handles.metricdata.IMG;
if handles.metricdata.settings.autocontrast.on
    if handles.metricdata.settings.currentmask==1 %don't autocontrast for mask2
        %CHANGED BY HENRY
        %ORIGINAL LINE:
        %IMG_current=imfilter(IMG_current, fspecial('gaussian',handles.metricdata.settings.autocontrast.blurrradius));
        IMG_current=imgaussfilt(IMG_current, handles.metricdata.settings.autocontrast.blurrradius);
        %END OF CHANGES
        IMG_current=autocontrast(IMG_current,handles.metricdata.settings.autocontrast.sigma);
    end
end

if strcmp(handles.metricdata.settings.edgemethod,'sobel') || strcmp(handles.metricdata.settings.edgemethod,'canny')
    IMG=edge(IMG_current, handles.metricdata.settings.edgemethod, handles.metricdata.svalue);
elseif strcmp(handles.metricdata.settings.edgemethod, 'threshold value')
    IMG=(IMG_current > handles.metricdata.svalue);
    %IMG=imfill(imdilate(IMG, handles.metricdata.settings.structure), 'holes');
    %IMG=imopen(IMG, handles.metricdata.settings.structure2);
    %IMG=imclose(IMG, handles.metricdata.settings.structure2);
elseif strcmp(handles.metricdata.settings.edgemethod, 'threshold particle variation')
    threshold=find_thresholdv1_2(IMG_current, round(handles.metricdata.svalue(1)), round(handles.metricdata.svalue(2)),handles.metricdata.settings.thresholdvalue.dilate,0);
    waitfor(threshold);
    IMG=(IMG_current > threshold);
else
    error('Edge detection method not supported. Exiting...');
end


if handles.metricdata.settings.imdilate
     IMG=imdilate(IMG, handles.metricdata.settings.structure);
end

if ~strcmp(handles.metricdata.settings.edgemethod, 'threshold value')
    IMG=imfill(IMG,'holes'); 
end

if isfield(handles.metricdata.settings, 'imdilate2')
    if handles.metricdata.settings.imdilate2
        IMG=imdilate(IMG, handles.metricdata.settings.structure);
    end
end

if handles.metricdata.settings.imopen
     IMG=imopen(IMG, handles.metricdata.settings.structure2);
end

if handles.metricdata.settings.imclose
     IMG=imclose(IMG,handles.metricdata.settings.structure2);
end
