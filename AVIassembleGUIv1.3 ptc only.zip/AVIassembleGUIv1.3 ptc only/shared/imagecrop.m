function IMGout=imagecrop(IMGin, cropvalue)

if cropvalue <= 100


imagedims=size(IMGin);
verticalcrop  =floor(0.5*double(100-cropvalue)*imagedims(1)/100);
horizontalcrop=floor(0.5*double(100-cropvalue)*imagedims(2)/100);
IMGout=IMGin(1+verticalcrop:end-verticalcrop,1+horizontalcrop:end-horizontalcrop);
imagedimsout=size(IMGout);
%display([num2str(cropvalue), ' crop ', num2str(imagedims), ' ', num2str(imagedimsout)]);

end