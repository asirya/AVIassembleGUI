%finds axis lengths for each cell
%
%Albert Siryaporn
%2013-08-13

function results=ptc_celldimensions(rc,phase)


settings.showimage=0;
settings.showpositions=0;
settings.showmax=0;
settings.plotfits=0;

settings.assigninbase=0;
settings.padding=5;

settings.mincellarea=250;
settings.maxcellarea=1500;
settings.mincellwidth=20;
settings.maxcellwidth=25;
settings.mincelllength=20;
settings.maxcelllength=100;

imagerc=zeros(size(phase,1),size(phase,2));
for i=1:length(rc)
    imagerc(rc(i,1),rc(i,2))=1;
end

if (min(rc(:,1)) > 5) && (min(rc(:,2)) > 5) && (max(rc(:,1)) < (size(phase,1)-5)) && (max(rc(:,2)) < (size(phase,2)-5))
    imagerc=imagerc( min(rc(:,1))-settings.padding:max(rc(:,1))+settings.padding,...
        min(rc(:,2))-settings.padding:max(rc(:,2))+settings.padding);
    
    imagep1=phase( min(rc(:,1))-settings.padding:max(rc(:,1))+settings.padding,...
        min(rc(:,2))-settings.padding:max(rc(:,2))+settings.padding);
   
    
    
    imagerc_props=regionprops(imagerc,'Centroid','MajorAxisLength','MinorAxisLength','Orientation','Area','Extent');
    
    if settings.assigninbase
        assignin('base', 'rc', rc);
        assignin('base', 'imagerc', imagerc);
        assignin('base', 'imagep1', imagep1);
        assignin('base', 'settings_localization', settings);
    end
    
    %imagep1_combined=uint16(imagerc).*imagep1;
    
    imagep1_combined=imagerc.*imagep1;
    
    if settings.assigninbase
        assignin('base', 'imagep1_combined', imagep1_combined);
        assignin('base', 'imagerc_props', imagerc_props);
    end
        
    if (imagerc_props.MinorAxisLength < settings.mincellwidth) || (imagerc_props.MinorAxisLength > settings.maxcellwidth) || ...
            (imagerc_props.MajorAxisLength < settings.mincelllength) || (imagerc_props.MajorAxisLength > settings.maxcelllength)
            %|| (imagerc_props.Area < settings.mincellarea) || (imagerc_props.Area > settings.maxcellarea)
        %imshow(imagep1_combined,[]);
        %satisfied=questdlg('Accept the rectange? ', 'Dialog', 'Yes', 'No', 'No');
        satisfied='No';
    else
        if settings.showimage
            imshow(imagep1_combined,[]);
            pause(0.05);
        end
        satisfied='Yes';
    end
    
    if strcmp(satisfied, 'Yes')
        results=[imagerc_props.Area imagerc_props.MinorAxisLength imagerc_props.MajorAxisLength];
    else
        display('cell rejected');
        results=[NaN NaN NaN];
    end
else
    display('cell out of bounds');
    results=[NaN NaN NaN];
end