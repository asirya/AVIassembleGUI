function value=mygauss(a, b, c, x)

value=a*exp(-((x-b)/c)^2);