function results = avg_intensity_filtered(varargin)

%this will filter out by cy5/cell area intensity
%will compute new peak to background intensity
%2018-05-07
%AS and HA
%

%2018-05-24
%Henry: Added stderr, added width filtering and standard error

data=varargin{1,1}{1,1};
localData = varargin{1,1}{9,1};

%Threshold value: Cy5/area under this gets thrown out
threshold=100;

peaksoverthreshold=[];
widthoverthreshold=[];

for i=1:length(data)
    if data(i,4) > threshold
       peaksoverthreshold=cat(1, peaksoverthreshold, data(i,6));
       widthoverthreshold=cat(1, widthoverthreshold, localData(i,4));
    end
end

%Finds average and standard error of filtered peaktobackground values
avgPk=mean(peaksoverthreshold);
avgPk_stderr=std(peaksoverthreshold)/length(peaksoverthreshold);

%Finds average and standard error of filtered fit width values
avgWth = mean(widthoverthreshold);
avgWth_stderr=std(widthoverthreshold)/length(widthoverthreshold);

%Number of cells that got filtered out
numRej = length(data) - length(peaksoverthreshold);

results  = [avgPk, avgPk_stderr, avgWth, avgWth_stderr, numRej];

