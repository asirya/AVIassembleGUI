function IMG=autocontrast(IMG_original,sigma)
%this function rescales cuts off image intensities that are greater or less than be sigma away from mean 
%Albert Siryaporn 7/17/12

settings.plothistogram=0;
bins=1:10:3500;

IMG=double(IMG_original);

%show histogram
if settings.plothistogram
    IMG2=reshape(IMG, [], 1);
    histnorm(IMG2, bins)
end

%saturate out of bounds intensities
bounds=arbbound(IMG,sigma);
IMG_mask=(IMG > bounds(1));
IMG=immultiply(IMG, IMG_mask);

IMG_maskkeep=(IMG < bounds(2));
IMG_masksaturate=(IMG > bounds(2));
IMG_maskadd=IMG_masksaturate*bounds(2);

IMG=immultiply(IMG,IMG_maskkeep);
IMG=imadd(IMG,IMG_maskadd);

IMG=IMG-bounds(1);

if settings.plothistogram
    figure;
    IMG2=reshape(IMG, [], 1);
    histnorm(IMG2, bins)
end

%imtool(IMG, []);
%%

function bounds=arbbound(IMG_original,sigma)
IMG=double(IMG_original);
IMG=reshape(IMG, [], 1); 
IMGstdev=std(double(IMG));
IMGmean=mean(IMG);
arblowerbound=IMGmean-IMGstdev*sigma;
arbupperbound=IMGmean+IMGstdev*sigma;
bounds=[arblowerbound arbupperbound];
%%